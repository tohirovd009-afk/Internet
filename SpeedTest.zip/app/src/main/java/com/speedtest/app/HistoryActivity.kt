package com.speedtest.app

import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.DateFormat
import java.util.Date
import kotlin.math.max

/** Oxirgi o'lchovlar tarixi: ustunli grafik va ro'yxat. */
class HistoryActivity : BaseActivity() {

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun text(
        s: CharSequence, sizeSp: Float, color: Int, bold: Boolean = false
    ): TextView = TextView(this).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val items = HistoryStore.load(this)
        val muted = 0xFF8A94B8.toInt()

        val scroll = ScrollView(this).apply {
            setBackgroundResource(R.drawable.bg_main)
            isFillViewport = true
            fitsSystemWindows = true
            isVerticalScrollBarEnabled = false
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(24))
        }
        scroll.addView(
            root,
            ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        // Sarlavha qatori
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val back = text("\u2190", 28f, Color.WHITE).apply {
            setPadding(0, 0, dp(16), 0)
            contentDescription = getString(R.string.btn_back)
            setOnClickListener { finish() }
        }
        header.addView(back)
        header.addView(text(getString(R.string.history_title), 26f, Color.WHITE, true))
        root.addView(header)

        if (items.isEmpty()) {
            val empty = text(getString(R.string.history_empty), 15f, muted).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(80), 0, 0)
            }
            root.addView(empty, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            setContentView(scroll)
            return
        }

        // Grafik (eng so'nggi 12 ta, chapdan o'ngga eskidan yangiga)
        val chartCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        val legend = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        legend.addView(text("\u25A0 " + getString(R.string.lbl_download), 11f, 0xFF22D3EE.toInt()))
        legend.addView(text("   \u25A0 " + getString(R.string.lbl_upload), 11f, 0xFFA855F7.toInt()))
        chartCard.addView(legend)
        val chart = ChartView(this, items.take(12).reversed())
        chartCard.addView(chart, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(150)).apply {
            topMargin = dp(8)
        })
        root.addView(chartCard, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(16) })

        // Ro'yxat
        val df = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
        for (e in items) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundResource(R.drawable.bg_card)
                setPadding(dp(16), dp(12), dp(16), dp(12))
            }
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            top.addView(text(df.format(Date(e.time)), 12f, muted),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            top.addView(text(e.net, 12f, 0xFF00E5A8.toInt()))
            card.addView(top)

            card.addView(
                text(
                    "\u2193 ${formatSpeed(e.down)}   \u2191 ${formatSpeed(e.up)}  Mbps",
                    19f, Color.WHITE, true
                ),
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { topMargin = dp(6) }
            )
            val detail = getString(R.string.history_detail, e.ping, e.jitter, e.loss)
            card.addView(text(detail, 12f, muted))
            val sub = listOf(e.isp, e.server).filter { it.isNotEmpty() }.joinToString("  \u2022  ")
            if (sub.isNotEmpty()) card.addView(text(sub, 11f, muted))

            root.addView(card, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })
        }

        // Tozalash
        val clear = text(getString(R.string.history_clear), 14f, 0xFFF43F5E.toInt(), true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(8))
            setOnClickListener {
                AlertDialog.Builder(this@HistoryActivity)
                    .setMessage(R.string.history_clear_confirm)
                    .setPositiveButton(R.string.btn_yes) { _, _ ->
                        HistoryStore.clear(this@HistoryActivity)
                        recreate()
                    }
                    .setNegativeButton(R.string.btn_cancel, null)
                    .show()
            }
        }
        root.addView(clear, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })

        setContentView(scroll)
    }

    /** Download (havorang) va upload (binafsha) ustunlari. */
    private class ChartView(ctx: Context, private val data: List<HistoryEntry>) : View(ctx) {
        private val density = ctx.resources.displayMetrics.density
        private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF26304F.toInt()
            strokeWidth = density
        }
        private val downPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF22D3EE.toInt() }
        private val upPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFA855F7.toInt() }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF8A94B8.toInt()
            textSize = 10f * density
        }
        private val rect = RectF()

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (data.isEmpty()) return
            var peak = 1.0
            for (e in data) peak = max(peak, max(e.down, e.up))

            val w = width.toFloat()
            val h = height.toFloat()
            val top = 14f * density
            val chartH = h - top

            for (i in 0..2) {
                val y = top + chartH * i / 2f
                canvas.drawLine(0f, y, w, y, gridPaint)
            }
            canvas.drawText(formatSpeed(peak) + " Mbps", 0f, top - 4f * density, textPaint)

            val slot = w / data.size
            val bar = slot * 0.3f
            val gap = slot * 0.04f
            val r = 3f * density
            for ((i, e) in data.withIndex()) {
                val center = slot * i + slot / 2f
                val dh = (chartH * (e.down / peak)).toFloat().coerceAtLeast(2f * density)
                val uh = (chartH * (e.up / peak)).toFloat().coerceAtLeast(2f * density)
                rect.set(center - gap - bar, h - dh, center - gap, h)
                canvas.drawRoundRect(rect, r, r, downPaint)
                rect.set(center + gap, h - uh, center + gap + bar, h)
                canvas.drawRoundRect(rect, r, r, upPaint)
            }
        }
    }
}
