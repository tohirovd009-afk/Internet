package com.speedtest.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class NetInfo(
    val ip: String,
    val isp: String,
    val asn: String,
    val city: String,
    val country: String,
    val colo: String
)

object NetInfoLoader {

    fun load(): NetInfo? {
        try {
            val j = JSONObject(get("https://speed.cloudflare.com/meta"))
            val coloRaw = j.opt("colo")
            val colo = when (coloRaw) {
                null -> ""
                is JSONObject -> coloRaw.optString("iata", coloRaw.optString("city", ""))
                else -> coloRaw.toString()
            }
            return NetInfo(
                j.optString("clientIp", ""),
                j.optString("asOrganization", ""),
                j.optString("asn", ""),
                j.optString("city", ""),
                j.optString("country", ""),
                colo
            )
        } catch (e: Exception) {
            // zaxira: oddiy trace
        }
        return try {
            var ip = ""
            var colo = ""
            var loc = ""
            for (line in get("https://speed.cloudflare.com/cdn-cgi/trace").lines()) {
                val p = line.split("=", limit = 2)
                if (p.size == 2) {
                    when (p[0]) {
                        "ip" -> ip = p[1]
                        "colo" -> colo = p[1]
                        "loc" -> loc = p[1]
                    }
                }
            }
            NetInfo(ip, "", "", "", loc, colo)
        } catch (e: Exception) {
            null
        }
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 6000
        c.readTimeout = 6000
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) InternetTezligi/1.0")
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }
}

data class HistoryEntry(
    val time: Long,
    val isp: String,
    val down: Double,
    val up: Double,
    val ping: Int,
    val jitter: Int
)

object HistoryStore {
    private const val PREFS = "history"
    private const val KEY = "items"
    private const val MAX = 30

    fun add(ctx: Context, e: HistoryEntry) {
        val list = ArrayList<HistoryEntry>(all(ctx))
        list.add(0, e)
        val arr = JSONArray()
        for (x in list.take(MAX)) {
            val o = JSONObject()
            o.put("t", x.time)
            o.put("isp", x.isp)
            o.put("d", x.down)
            o.put("u", x.up)
            o.put("p", x.ping)
            o.put("j", x.jitter)
            arr.put(o)
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun all(ctx: Context): List<HistoryEntry> {
        val out = ArrayList<HistoryEntry>()
        try {
            val s = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return out
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    HistoryEntry(
                        o.optLong("t"), o.optString("isp"), o.optDouble("d"),
                        o.optDouble("u"), o.optInt("p"), o.optInt("j")
                    )
                )
            }
        } catch (e: Exception) {
        }
        return out
    }
}
