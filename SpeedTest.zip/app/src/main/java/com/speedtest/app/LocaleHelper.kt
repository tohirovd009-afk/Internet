package com.speedtest.app

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import java.util.Locale

/** Ilova tilini boshqaradi: uz (standart), ru, en. */
object LocaleHelper {
    private const val PREFS = "settings"
    private const val KEY = "lang"
    private val LANGS = arrayOf("uz", "ru", "en")

    fun current(ctx: Context): String {
        val saved = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
        if (saved != null && saved in LANGS) return saved
        return when (Locale.getDefault().language) {
            "ru" -> "ru"
            "en" -> "en"
            else -> "uz"
        }
    }

    fun next(ctx: Context): String {
        val n = LANGS[(LANGS.indexOf(current(ctx)) + 1) % LANGS.size]
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, n).apply()
        return n
    }

    fun wrap(base: Context): Context {
        val locale = Locale.forLanguageTag(current(base))
        Locale.setDefault(locale)
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(locale)
        return base.createConfigurationContext(cfg)
    }
}

open class BaseActivity : Activity() {
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
}
