package com.speedtest.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class HistoryEntry(
    val time: Long,
    val net: String,
    val down: Double,
    val up: Double,
    val ping: Int,
    val jitter: Int,
    val loss: Int,
    val loaded: Int,
    val isp: String,
    val server: String
)

/** Oxirgi 50 ta natijani SharedPreferences ichida JSON ko'rinishida saqlaydi. */
object HistoryStore {
    private const val PREFS = "history"
    private const val KEY = "items"
    private const val MAX = 50

    /** Eng yangisi birinchi. */
    fun load(ctx: Context): List<HistoryEntry> {
        val raw = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, null) ?: return emptyList()
        val out = ArrayList<HistoryEntry>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    HistoryEntry(
                        o.optLong("t"), o.optString("n"),
                        o.optDouble("d"), o.optDouble("u"),
                        o.optInt("p"), o.optInt("j"), o.optInt("l"), o.optInt("lp"),
                        o.optString("isp"), o.optString("srv")
                    )
                )
            }
        } catch (e: Exception) {
            return emptyList()
        }
        return out
    }

    fun add(ctx: Context, e: HistoryEntry) {
        val list = ArrayList<HistoryEntry>(load(ctx))
        list.add(0, e)
        while (list.size > MAX) list.removeAt(list.size - 1)
        val arr = JSONArray()
        for (x in list) {
            arr.put(
                JSONObject()
                    .put("t", x.time).put("n", x.net)
                    .put("d", x.down).put("u", x.up)
                    .put("p", x.ping).put("j", x.jitter).put("l", x.loss).put("lp", x.loaded)
                    .put("isp", x.isp).put("srv", x.server)
            )
        }
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }

    fun clear(ctx: Context) {
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().remove(KEY).apply()
    }
}
