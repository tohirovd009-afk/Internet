package com.speedtest.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View
import java.util.Locale
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.min
import kotlin.math.sin

fun formatSpeed(v: Double): String = when {
    v < 10 -> String.format(Locale.US, "%.2f", v)
    v < 100 -> String.format(Locale.US, "%.1f", v)
    else -> String.format(Locale.US, "%.0f", v)
}

class GaugeView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = 0xFF232842.toInt()
    }
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = 0xFF00E5A8.toInt()
    }
    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF6B7194.toInt()
        textAlign = Paint.Align.CENTER
    }
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val unitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF8A90A8.toInt()
        textAlign = Paint.Align.CENTER
    }

    private val rect = RectF()
    private var shown = 0f
    private var valueText = "0"
    private var animator: ValueAnimator? = null
    private val ticks = doubleArrayOf(0.0, 5.0, 10.0, 50.0, 100.0, 500.0, 1000.0)

    fun setSpeed(mbps: Double) {
        valueText = if (mbps <= 0.0) "0" else formatSpeed(mbps)
        animateTo(fraction(mbps))
    }

    fun reset() = setSpeed(0.0)

    private fun animateTo(target: Float) {
        animator?.cancel()
        animator = ValueAnimator.ofFloat(shown, target).apply {
            duration = 300
            addUpdateListener {
                shown = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val size = min(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val stroke = size * 0.07f
        trackPaint.strokeWidth = stroke
        arcPaint.strokeWidth = stroke

        val r = size / 2f - stroke
        rect.set(cx - r, cy - r, cx + r, cy + r)
        canvas.drawArc(rect, START, SWEEP, false, trackPaint)
        if (shown > 0.002f) {
            canvas.drawArc(rect, START, SWEEP * shown, false, arcPaint)
        }

        tickPaint.textSize = size * 0.04f
        val rl = r - stroke * 1.4f
        for (t in ticks) {
            val a = Math.toRadians((START + SWEEP * fraction(t)).toDouble())
            val x = cx + rl * cos(a).toFloat()
            val y = cy + rl * sin(a).toFloat() + tickPaint.textSize / 3f
            canvas.drawText(t.toInt().toString(), x, y, tickPaint)
        }

        valuePaint.textSize = size * 0.2f
        canvas.drawText(valueText, cx, cy + size * 0.04f, valuePaint)
        unitPaint.textSize = size * 0.065f
        canvas.drawText("Mbps", cx, cy + size * 0.14f, unitPaint)
    }

    companion object {
        private const val START = 135f
        private const val SWEEP = 270f

        private fun fraction(v: Double): Float =
            (ln(1.0 + v) / ln(1001.0)).coerceIn(0.0, 1.0).toFloat()
    }
}
