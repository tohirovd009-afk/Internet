package com.speedtest.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

fun formatSpeed(v: Double): String = when {
    v < 10 -> String.format(Locale.US, "%.2f", v)
    v < 100 -> String.format(Locale.US, "%.1f", v)
    else -> String.format(Locale.US, "%.0f", v)
}

/**
 * Mashina spidometriga o'xshash o'lchagich.
 * Shkala, raqamlar va ramka bir marta Bitmap ga chiziladi (tez ishlashi uchun),
 * har kadrda faqat strelka, rangli yoy va raqamli ko'rsatkich chiziladi.
 * Shkala tezlikka qarab avtomatik kengayadi (25 -> 50 -> 100 -> 200 -> 500 -> 1000 Mbps).
 */
class GaugeView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private class Scale(val max: Int, val major: Int, val minor: Int)

    private val scales = arrayOf(
        Scale(10, 2, 4),
        Scale(25, 5, 5),
        Scale(50, 10, 5),
        Scale(100, 10, 5),
        Scale(200, 20, 4),
        Scale(500, 50, 5),
        Scale(1000, 100, 5)
    )

    private var scaleIndex = DEFAULT_SCALE
    private var faceDirty = true

    private var shown = 0f
    private var target = 0f
    private var valueText = "0.00"
    private var label = ""

    private var lastFrame = 0L
    private var face: Bitmap? = null
    private var faceCanvas: Canvas? = null
    private var cx = 0f
    private var cy = 0f
    private var radius = 0f
    private val arcRect = RectF()
    private val needlePath = Path()

    private val bezelPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dialPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFF2A3358.toInt()
    }
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = 0xFF1E2545.toInt()
    }
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val majorTickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = 0xFFE6E9F5.toInt()
    }
    private val minorTickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = 0xFF626B91.toInt()
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFC7CCE0.toInt()
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val needlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFFFF5A3C.toInt()
    }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0x66000000
    }
    private val hubPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFF151B36.toInt()
    }
    private val hubRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFFFF5A3C.toInt()
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFFFF5A3C.toInt()
    }
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val unitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF8A94B8.toInt()
        textAlign = Paint.Align.CENTER
        letterSpacing = 0.12f
    }
    private val captionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF00E5A8.toInt()
        textAlign = Paint.Align.CENTER
        letterSpacing = 0.15f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    // ---------- Public API ----------

    /** Shkala almashganda strelka o'sha tezlikka ishora qilib qoladi (noto'g'ri raqamga siljimaydi). */
    private fun changeScale(idx: Int) {
        if (idx == scaleIndex) return
        shown *= scales[scaleIndex].max.toFloat() / scales[idx].max
        scaleIndex = idx
        faceDirty = true
    }

    fun setSpeed(mbps: Double) {
        var idx = scaleIndex
        while (idx < scales.size - 1 && mbps > scales[idx].max * 0.94) idx++
        changeScale(idx)
        valueText = formatSpeed(mbps)
        target = (mbps / scales[scaleIndex].max).toFloat().coerceIn(0f, 1f)
        invalidate()
    }

    fun reset() {
        changeScale(DEFAULT_SCALE)
        valueText = formatSpeed(0.0)
        target = 0f
        invalidate()
    }

    fun setLabel(text: String) {
        label = text
        invalidate()
    }

    // ---------- Layout ----------

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val maxPx = (340 * resources.displayMetrics.density).toInt()
        val s = if (w > 0) min(w, maxPx) else maxPx
        setMeasuredDimension(s, s)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w <= 0 || h <= 0) return

        cx = w / 2f
        cy = h / 2f
        radius = min(w, h) / 2f * 0.98f
        val r = radius

        ringPaint.strokeWidth = r * 0.008f
        trackPaint.strokeWidth = r * 0.05f
        arcPaint.strokeWidth = r * 0.05f
        majorTickPaint.strokeWidth = r * 0.014f
        minorTickPaint.strokeWidth = r * 0.007f
        hubRingPaint.strokeWidth = r * 0.014f
        labelPaint.textSize = r * 0.07f
        valuePaint.textSize = r * 0.19f
        unitPaint.textSize = r * 0.075f
        captionPaint.textSize = r * 0.06f

        val ar = r * 0.895f
        arcRect.set(cx - ar, cy - ar, cx + ar, cy + ar)
        arcPaint.shader = SweepGradient(
            cx, cy,
            intArrayOf(
                0xFF22D3EE.toInt(), 0xFF3B82F6.toInt(), 0xFFA855F7.toInt(),
                0xFFF43F5E.toInt(), 0xFFF43F5E.toInt()
            ),
            floatArrayOf(0f, 0.25f, 0.5f, 0.75f, 1f)
        )

        needlePath.reset()
        needlePath.moveTo(r * 0.80f, 0f)
        needlePath.lineTo(0f, -r * 0.026f)
        needlePath.lineTo(-r * 0.15f, -r * 0.014f)
        needlePath.lineTo(-r * 0.15f, r * 0.014f)
        needlePath.lineTo(0f, r * 0.026f)
        needlePath.close()

        face?.recycle()
        face = null
        faceCanvas = null
        faceDirty = true
    }

    private fun ensureFace(): Bitmap? {
        if (face == null && width > 0 && height > 0) {
            val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            face = bmp
            faceCanvas = Canvas(bmp)
            faceDirty = true
        }
        return face
    }

    // ---------- Drawing ----------

    private fun buildFace() {
        val c = faceCanvas ?: return
        face?.eraseColor(Color.TRANSPARENT)
        val r = radius

        bezelPaint.shader = LinearGradient(
            cx, cy - r, cx, cy + r,
            0xFF3B4366.toInt(), 0xFF0C1022.toInt(), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, r, bezelPaint)

        dialPaint.shader = RadialGradient(
            cx, cy, r * 0.95f,
            intArrayOf(0xFF1B2246.toInt(), 0xFF0A0D1C.toInt()),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, r * 0.95f, dialPaint)
        c.drawCircle(cx, cy, r * 0.95f, ringPaint)

        c.drawArc(arcRect, START, SWEEP, false, trackPaint)

        val s = scales[scaleIndex]
        val n = s.max / s.major * s.minor
        val fm = labelPaint.fontMetrics
        for (i in 0..n) {
            val major = i % s.minor == 0
            val a = Math.toRadians(START + SWEEP * i / n.toDouble())
            val ca = cos(a).toFloat()
            val sa = sin(a).toFloat()
            val outer = r * 0.84f
            val inner = outer - r * (if (major) 0.10f else 0.05f)
            c.drawLine(
                cx + ca * outer, cy + sa * outer,
                cx + ca * inner, cy + sa * inner,
                if (major) majorTickPaint else minorTickPaint
            )
            if (major) {
                val v = s.major * (i / s.minor)
                val lx = cx + ca * r * 0.60f
                val ly = cy + sa * r * 0.60f - (fm.ascent + fm.descent) / 2f
                c.drawText(v.toString(), lx, ly, labelPaint)
            }
        }

        c.drawText("Mbps", cx, cy + r * 0.70f, unitPaint)
        faceDirty = false
    }

    override fun onDraw(canvas: Canvas) {
        val bmp = ensureFace() ?: return
        if (faceDirty) buildFace()
        canvas.drawBitmap(bmp, 0f, 0f, null)

        // Strelka vaqtga bog'liq silliq harakatlanadi: 60 Hz va 120 Hz ekranda bir xil tezlikda
        val now = System.nanoTime()
        val dt = if (lastFrame == 0L) 0.016f else ((now - lastFrame) / 1e9f).coerceIn(0.001f, 0.1f)
        val diff = target - shown
        if (abs(diff) > 0.0004f) {
            lastFrame = now
            shown += diff * (1f - exp(-dt / SMOOTH_TAU))
            postInvalidateOnAnimation()
        } else {
            shown = target
            lastFrame = 0L
        }

        val r = radius
        if (shown > 0.004f) {
            canvas.save()
            canvas.rotate(START, cx, cy)
            canvas.drawArc(arcRect, 0f, SWEEP * shown, false, arcPaint)
            canvas.restore()
        }

        val angle = START + SWEEP * shown
        canvas.save()
        canvas.translate(cx + r * 0.012f, cy + r * 0.02f)
        canvas.rotate(angle)
        canvas.drawPath(needlePath, shadowPaint)
        canvas.restore()

        canvas.save()
        canvas.translate(cx, cy)
        canvas.rotate(angle)
        canvas.drawPath(needlePath, needlePaint)
        canvas.restore()

        canvas.drawCircle(cx, cy, r * 0.085f, hubPaint)
        canvas.drawCircle(cx, cy, r * 0.085f, hubRingPaint)
        canvas.drawCircle(cx, cy, r * 0.03f, dotPaint)

        if (label.isNotEmpty()) {
            canvas.drawText(label, cx, cy + r * 0.31f, captionPaint)
        }
        canvas.drawText(valueText, cx, cy + r * 0.56f, valuePaint)
    }

    companion object {
        private const val START = 135f
        private const val SWEEP = 270f
        private const val SMOOTH_TAU = 0.09f
        private const val DEFAULT_SCALE = 1 // 25 Mbps
    }
}
