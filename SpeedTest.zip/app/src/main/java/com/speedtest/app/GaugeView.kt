package com.speedtest.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Kartochkalar uchun format: 3.45 / 31,2 / 317 */
fun formatSpeed(v: Double): String {
    val s = when {
        v < 10 -> String.format(Locale.US, "%.2f", v)
        v < 100 -> String.format(Locale.US, "%.1f", v)
        else -> String.format(Locale.US, "%.0f", v)
    }
    return s.replace('.', ',')
}

/** Spidometr markazidagi katta raqam: 139,31 */
fun formatReadout(v: Double): String {
    val s = if (v < 1000) String.format(Locale.US, "%.2f", v) else String.format(Locale.US, "%.0f", v)
    return s.replace('.', ',')
}

/**
 * Premium spidometr: qalin rangli yoy, nochiziqli shkala (0 5 10 50 100 250 500 750 1k),
 * ingichka strelka va katta raqamli ko'rsatkich.
 * Statik qism (halqa, shkala, raqamlar) bir marta Bitmap ga chiziladi - tez ishlaydi.
 */
class GaugeView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val scaleValues = arrayOf(
        doubleArrayOf(0.0, 1.0, 5.0, 10.0, 20.0, 30.0, 50.0, 75.0, 100.0),
        doubleArrayOf(0.0, 5.0, 10.0, 25.0, 50.0, 100.0, 200.0, 350.0, 500.0),
        doubleArrayOf(0.0, 5.0, 10.0, 50.0, 100.0, 250.0, 500.0, 750.0, 1000.0)
    )
    private val scaleLabels = arrayOf(
        arrayOf("0", "1", "5", "10", "20", "30", "50", "75", "100"),
        arrayOf("0", "5", "10", "25", "50", "100", "200", "350", "500"),
        arrayOf("0", "5", "10", "50", "100", "250", "500", "750", "1k")
    )

    private var scaleIdx = 2
    private var phase = 0 // 0 - kutish/ping, 1 - download, 2 - upload
    private var faceDirty = true
    private var iconColor = 0xFFE0A526.toInt()

    private var shown = 0f
    private var target = 0f
    private var lastMbps = 0.0
    private var valueText = "0,00"
    private var unit = "Mbps"

    private var face: Bitmap? = null
    private var faceCanvas: Canvas? = null
    private var cx = 0f
    private var cy = 0f
    private var radius = 0f
    private val arcRect = RectF()
    private val needlePath = Path()

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFF1B2240.toInt()
    }
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }
    private val majorTickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = 0xFF7C86AA.toInt()
    }
    private val minorTickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = 0xFF39426A.toInt()
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFEDEFF8.toInt()
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val needlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFFF5C451.toInt()
    }
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
    }
    private val unitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF9AA3C4.toInt()
        textAlign = Paint.Align.LEFT
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    // ---------- Public API ----------

    fun setScale(max: Int) {
        val idx = when (max) {
            100 -> 0
            500 -> 1
            else -> 2
        }
        if (idx != scaleIdx) {
            scaleIdx = idx
            faceDirty = true
            target = fraction(lastMbps)
            invalidate()
        }
    }

    fun setPhase(p: Int) {
        phase = p
        applyArcShader()
        invalidate()
    }

    fun setUnit(text: String) {
        unit = text
        invalidate()
    }

    /** mbps - strelka uchun (har doim Mbps), display - markazdagi raqam matni. */
    fun setSpeed(mbps: Double, display: String) {
        lastMbps = mbps
        valueText = display
        target = fraction(mbps)
        invalidate()
    }

    fun reset() {
        lastMbps = 0.0
        valueText = formatReadout(0.0)
        target = 0f
        invalidate()
    }

    // ---------- Math ----------

    private fun fraction(v: Double): Float {
        val a = scaleValues[scaleIdx]
        if (v <= 0.0) return 0f
        if (v >= a[a.size - 1]) return 1f
        var i = 0
        while (i < a.size - 2 && v > a[i + 1]) i++
        val f = (v - a[i]) / (a[i + 1] - a[i])
        return ((i + f) / (a.size - 1)).toFloat()
    }

    // ---------- Layout ----------

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val maxPx = (360 * resources.displayMetrics.density).toInt()
        val s = if (w > 0) min(w, maxPx) else maxPx
        setMeasuredDimension(s, s)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w <= 0 || h <= 0) return

        cx = w / 2f
        cy = h / 2f
        radius = min(w, h) / 2f * 0.98f
        val r = radius

        val stroke = r * 0.175f
        trackPaint.strokeWidth = stroke
        arcPaint.strokeWidth = stroke
        val ar = r - stroke / 2f
        arcRect.set(cx - ar, cy - ar, cx + ar, cy + ar)

        majorTickPaint.strokeWidth = r * 0.012f
        minorTickPaint.strokeWidth = r * 0.007f
        labelPaint.textSize = r * 0.082f
        valuePaint.textSize = r * 0.36f
        unitPaint.textSize = r * 0.085f
        iconPaint.strokeWidth = r * 0.014f

        glowPaint.shader = RadialGradient(
            cx, cy, r * 0.82f,
            intArrayOf(0x3318214A, 0x00000000),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )

        // ingichka konussimon strelka (markazdan chiqib, tashqariga yorqinlashadi)
        val tip = r * 0.58f
        needlePath.reset()
        needlePath.moveTo(tip, 0f)
        needlePath.lineTo(r * 0.04f, -r * 0.05f)
        needlePath.lineTo(r * 0.04f, r * 0.05f)
        needlePath.close()
        needlePaint.shader = LinearGradient(
            r * 0.04f, 0f, tip, 0f,
            0x00FFFFFF, 0xFFFFFFFF.toInt(), Shader.TileMode.CLAMP
        )

        applyArcShader()

        face?.recycle()
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        face = bmp
        faceCanvas = Canvas(bmp)
        faceDirty = true
    }

    private fun applyArcShader() {
        if (radius <= 0f) return
        val c0: Int
        val c1: Int
        when (phase) {
            1 -> { c0 = 0xFF00A8FF.toInt(); c1 = 0xFF00E5C3.toInt() }
            2 -> { c0 = 0xFF8A3FFC.toInt(); c1 = 0xFFFF5AC8.toInt() }
            else -> { c0 = 0xFFFFE3A3.toInt(); c1 = 0xFFE0A526.toInt() }
        }
        iconColor = c1
        arcPaint.shader = SweepGradient(
            cx, cy,
            intArrayOf(c0, c1, c1),
            floatArrayOf(0f, 0.75f, 1f)
        )
    }

    // ---------- Drawing ----------

    private fun buildFace() {
        val c = faceCanvas ?: return
        face?.eraseColor(Color.TRANSPARENT)
        val r = radius

        c.drawCircle(cx, cy, r * 0.82f, glowPaint)
        c.drawArc(arcRect, START, SWEEP, false, trackPaint)

        // mayda va yirik chiziqlar (aniq o'qish uchun)
        val intervals = scaleValues[scaleIdx].size - 1
        val total = intervals * 5
        for (i in 0..total) {
            val major = i % 5 == 0
            val a = Math.toRadians(START + SWEEP * i / total.toDouble())
            val ca = cos(a).toFloat()
            val sa = sin(a).toFloat()
            val outer = r * 0.665f
            val inner = outer - r * (if (major) 0.045f else 0.024f)
            c.drawLine(
                cx + ca * outer, cy + sa * outer,
                cx + ca * inner, cy + sa * inner,
                if (major) majorTickPaint else minorTickPaint
            )
        }

        // raqamlar
        val labels = scaleLabels[scaleIdx]
        val fm = labelPaint.fontMetrics
        for (i in labels.indices) {
            val a = Math.toRadians(START + SWEEP * i / (labels.size - 1).toDouble())
            val lx = cx + cos(a).toFloat() * r * 0.735f
            val ly = cy + sin(a).toFloat() * r * 0.735f - (fm.ascent + fm.descent) / 2f
            c.drawText(labels[i], lx, ly, labelPaint)
        }
        faceDirty = false
    }

    override fun onDraw(canvas: Canvas) {
        val bmp = face ?: return
        if (faceDirty) buildFace()
        canvas.drawBitmap(bmp, 0f, 0f, null)

        // strelka har kadrda maqsadga silliq yaqinlashadi
        val diff = target - shown
        if (abs(diff) > 0.0004f) {
            shown += diff * 0.18f
            postInvalidateOnAnimation()
        } else {
            shown = target
        }

        val r = radius
        if (shown > 0.003f) {
            canvas.save()
            canvas.rotate(START, cx, cy)
            canvas.drawArc(arcRect, 0f, SWEEP * shown, false, arcPaint)
            canvas.restore()
        }

        val angle = START + SWEEP * shown
        canvas.save()
        canvas.translate(cx, cy)
        canvas.rotate(angle)
        canvas.drawPath(needlePath, needlePaint)
        canvas.restore()
        canvas.drawCircle(cx, cy, r * 0.022f, dotPaint)

        canvas.drawText(valueText, cx, cy + r * 0.66f, valuePaint)
        drawUnitRow(canvas, cy + r * 0.80f)
    }

    private fun drawUnitRow(canvas: Canvas, y: Float) {
        val r = radius
        val tw = unitPaint.measureText(unit)
        val iconD = if (phase == 0) 0f else r * 0.10f
        val gap = if (phase == 0) 0f else r * 0.04f
        val startX = cx - (iconD + gap + tw) / 2f

        if (phase != 0) {
            val ir = iconD / 2f
            val icx = startX + ir
            val icy = y - unitPaint.textSize * 0.33f
            iconPaint.color = iconColor
            canvas.drawCircle(icx, icy, ir, iconPaint)
            val len = ir * 0.45f
            val s = if (phase == 1) 1f else -1f
            canvas.drawLine(icx, icy - len * s, icx, icy + len * s, iconPaint)
            canvas.drawLine(icx - len * 0.75f, icy + len * 0.2f * s, icx, icy + len * s, iconPaint)
            canvas.drawLine(icx + len * 0.75f, icy + len * 0.2f * s, icx, icy + len * s, iconPaint)
        }
        canvas.drawText(unit, startX + iconD + gap, y, unitPaint)
    }

    override fun onDetachedFromWindow() {
        face?.recycle()
        face = null
        faceCanvas = null
        super.onDetachedFromWindow()
    }

    companion object {
        private const val START = 135f
        private const val SWEEP = 270f
    }
}
