package com.speedtest.app

import android.os.Process
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Collections
import java.util.Random
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs
import kotlin.math.min

class SpeedTester(private val listener: Listener) {

    enum class Phase { PING, DOWNLOAD, UPLOAD }

    class PingResult(val ping: Int, val jitter: Int, val lossPercent: Int)

    class ServerInfo(val isp: String, val server: String, val ip: String)

    /** Barcha callbacklar fon oqimidan chaqiriladi - UI ga runOnUiThread bilan o'tkazing. */
    interface Listener {
        fun onPhase(phase: Phase)
        fun onPing(result: PingResult)
        fun onSpeed(phase: Phase, mbps: Double)
        fun onResult(phase: Phase, mbps: Double)
        fun onLoadedPing(ms: Int)
        fun onDone(usedBytes: Long)
        fun onError()
    }

    private val cancelled = AtomicBoolean(false)
    private val connections = Collections.synchronizedSet(HashSet<HttpURLConnection>())
    private val used = AtomicLong(0)

    @Volatile
    private var upChunk = UP_CHUNK_MIN

    @Volatile
    private var loadedPing = 0

    fun start() {
        cancelled.set(false)
        Thread({
            Process.setThreadPriority(WORKER_PRIORITY)
            execute()
        }, "speedtest-main").start()
    }

    fun cancel() {
        cancelled.set(true)
        closeAll()
    }

    private fun emit(block: () -> Unit) {
        if (!cancelled.get()) block()
    }

    private fun execute() {
        try {
            emit { listener.onPhase(Phase.PING) }
            val ping = measurePing()
            if (cancelled.get()) return
            emit { listener.onPing(ping) }

            emit { listener.onPhase(Phase.DOWNLOAD) }
            val down = measureThroughput(Phase.DOWNLOAD, DOWNLOAD_SECONDS)
            if (cancelled.get()) return
            emit { listener.onResult(Phase.DOWNLOAD, down) }
            val lp = loadedPing
            if (lp > 0) emit { listener.onLoadedPing(lp) }

            emit { listener.onPhase(Phase.UPLOAD) }
            val up = measureThroughput(Phase.UPLOAD, UPLOAD_SECONDS)
            if (cancelled.get()) return
            emit { listener.onResult(Phase.UPLOAD, up) }

            val total = used.get()
            emit { listener.onDone(total) }
        } catch (e: Exception) {
            emit { listener.onError() }
        }
    }

    private fun open(url: String, timeout: Int = IO_TIMEOUT): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = timeout
        c.readTimeout = timeout
        c.useCaches = false
        c.setRequestProperty("Accept-Encoding", "identity")
        c.setRequestProperty("Cache-Control", "no-cache")
        c.setRequestProperty("User-Agent", USER_AGENT)
        connections.add(c)
        return c
    }

    private fun release(c: HttpURLConnection?) {
        if (c != null) connections.remove(c)
    }

    private fun closeAll() {
        val copy = synchronized(connections) { connections.toList() }
        connections.clear()
        for (c in copy) {
            try {
                c.disconnect()
            } catch (ignored: Exception) {
            }
        }
    }

    /** Bitta yengil so'rov vaqti (ms). Xato bo'lsa -1. */
    private fun oneRoundTrip(skip: ByteArray): Double {
        var c: HttpURLConnection? = null
        return try {
            val t0 = System.nanoTime()
            c = open("$BASE/__down?bytes=0", PING_TIMEOUT)
            c.inputStream.use { while (it.read(skip) >= 0) { /* drain */ } }
            (System.nanoTime() - t0) / 1_000_000.0
        } catch (e: Exception) {
            -1.0
        } finally {
            release(c)
        }
    }

    private fun measurePing(): PingResult {
        val samples = ArrayList<Double>()
        val skip = ByteArray(512)
        var failed = 0
        for (i in 0 until PING_COUNT) {
            if (cancelled.get()) break
            val ms = oneRoundTrip(skip)
            // birinchi so'rov (TLS ulanishi) hisobga olinmaydi
            if (i > 0) {
                if (ms >= 0) samples.add(ms) else if (!cancelled.get()) failed++
            }
            try {
                Thread.sleep(100)
            } catch (e: InterruptedException) {
                break
            }
        }
        if (cancelled.get()) return PingResult(0, 0, 0)
        if (samples.isEmpty()) throw IOException("no server")

        val sorted = samples.sorted()
        val median = if (sorted.size % 2 == 1) sorted[sorted.size / 2]
        else (sorted[sorted.size / 2 - 1] + sorted[sorted.size / 2]) / 2.0

        var jitter = 0.0
        for (i in 1 until samples.size) jitter += abs(samples[i] - samples[i - 1])
        if (samples.size > 1) jitter /= (samples.size - 1)

        val attempts = samples.size + failed
        val loss = if (attempts > 0) failed * 100 / attempts else 0
        return PingResult(median.toInt(), jitter.toInt(), loss)
    }

    /** Yuklanish paytida ping (bufferbloat) - download vaqtida parallel o'lchanadi. */
    private fun loadedPingLoop(stop: AtomicBoolean, t0: Long, out: MutableList<Double>) {
        Process.setThreadPriority(WORKER_PRIORITY)
        val skip = ByteArray(512)
        while (!stop.get() && !cancelled.get()) {
            try {
                Thread.sleep(250)
            } catch (e: InterruptedException) {
                return
            }
            if ((System.nanoTime() - t0) / 1e9 < WARMUP_SECONDS) continue
            val ms = oneRoundTrip(skip)
            if (ms >= 0 && !stop.get()) synchronized(out) { out.add(ms) }
        }
    }

    private fun measureThroughput(phase: Phase, durationSec: Int): Double {
        val total = AtomicLong(0)
        val stop = AtomicBoolean(false)
        val workers = ArrayList<Thread>()
        val loadedSamples = ArrayList<Double>()
        var latencyThread: Thread? = null

        fun spawn(n: Int) {
            synchronized(workers) {
                repeat(n) {
                    workers.add(Thread({ worker(phase, total, stop) }, "speedtest-worker").also { it.start() })
                }
            }
        }

        upChunk = UP_CHUNK_MIN
        val t0 = System.nanoTime()
        spawn(THREADS_START)
        if (phase == Phase.DOWNLOAD) {
            latencyThread = Thread({ loadedPingLoop(stop, t0, loadedSamples) }, "speedtest-latency").also { it.start() }
        }

        // Oxirgi ~1 soniyalik oyna bo'yicha tezlik - ko'rsatkich silliq va barqaror bo'ladi
        val times = ArrayDeque<Long>()
        val bytesQ = ArrayDeque<Long>()
        times.addLast(t0)
        bytesQ.addLast(0L)

        var warmB = -1L
        var warmT = 0L
        var boosted = false
        var result = 0.0

        try {
            while (true) {
                Thread.sleep(SAMPLE_MS)
                if (cancelled.get()) return 0.0
                val now = System.nanoTime()
                val b = total.get()
                val elapsed = (now - t0) / 1e9

                times.addLast(now)
                bytesQ.addLast(b)
                while (times.size > 2 && now - times.first() > WINDOW_NS) {
                    times.removeFirst()
                    bytesQ.removeFirst()
                }
                val dt = (now - times.first()) / 1e9
                val speed = if (dt > 0) (b - bytesQ.first()) * 8.0 / dt / 1e6 else 0.0

                if (warmB < 0 && elapsed >= WARMUP_SECONDS) {
                    warmB = b
                    warmT = now
                }

                // Tez internetda oqimlar sonini oshiramiz (gigabit tarmoqni to'ldirish uchun)
                if (!boosted && elapsed >= 1.5) {
                    val limit = if (phase == Phase.DOWNLOAD) BOOST_DOWN_MBPS else BOOST_UP_MBPS
                    if (speed > limit) {
                        boosted = true
                        spawn(THREADS_BOOST)
                    }
                }

                // Upload: har bir bo'lak ~0.4 soniyalik ma'lumot bo'ladi (aniqlik uchun)
                if (phase == Phase.UPLOAD) {
                    val threadsNow = synchronized(workers) { workers.size }
                    val perThread = speed * 1e6 / 8.0 / threadsNow
                    upChunk = (perThread * 0.4).toInt().coerceIn(UP_CHUNK_MIN, UP_CHUNK_MAX)
                }

                emit { listener.onSpeed(phase, speed) }

                if (b == 0L && elapsed > 6) {
                    throw IOException("no data")
                }
                if (elapsed >= durationSec) break
            }
            val bytes = total.get() - warmB
            val secs = (System.nanoTime() - warmT) / 1e9
            result = if (secs > 0) bytes * 8.0 / secs / 1e6 else 0.0
        } finally {
            stop.set(true)
            closeAll()
            used.addAndGet(total.get())
            synchronized(workers) { workers.toList() }.forEach { it.join(1500) }
            latencyThread?.join(1500)
        }

        if (phase == Phase.DOWNLOAD) {
            val copy = synchronized(loadedSamples) { loadedSamples.sorted() }
            loadedPing = if (copy.isEmpty()) 0 else copy[copy.size / 2].toInt()
        }
        return result
    }

    private fun worker(phase: Phase, total: AtomicLong, stop: AtomicBoolean) {
        Process.setThreadPriority(WORKER_PRIORITY)
        val buf = ByteArray(64 * 1024)
        if (phase == Phase.UPLOAD) Random().nextBytes(buf)
        val skip = ByteArray(1024)
        while (!stop.get() && !cancelled.get()) {
            var c: HttpURLConnection? = null
            try {
                if (phase == Phase.DOWNLOAD) {
                    c = open("$BASE/__down?bytes=$DOWN_CHUNK")
                    c.inputStream.use { ins ->
                        while (!stop.get()) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            total.addAndGet(n.toLong())
                        }
                    }
                } else {
                    val size = upChunk
                    c = open("$BASE/__up")
                    c.requestMethod = "POST"
                    c.doOutput = true
                    c.setRequestProperty("Content-Type", "application/octet-stream")
                    c.setFixedLengthStreamingMode(size)
                    c.outputStream.use { os ->
                        var sent = 0
                        while (sent < size && !stop.get()) {
                            val n = min(buf.size, size - sent)
                            os.write(buf, 0, n)
                            sent += n
                        }
                    }
                    if (stop.get()) return
                    // Bayt faqat server qabul qilganini tasdiqlagandan keyin hisoblanadi
                    val code = c.responseCode
                    try {
                        val body = if (code < 400) c.inputStream else c.errorStream
                        body?.use { while (it.read(skip) >= 0) { /* drain */ } }
                    } catch (ignored: Exception) {
                    }
                    if (code in 200..299) total.addAndGet(size.toLong())
                }
            } catch (e: Exception) {
                if (stop.get() || cancelled.get()) return
                try {
                    Thread.sleep(300)
                } catch (ignored: InterruptedException) {
                    return
                }
            } finally {
                release(c)
            }
        }
    }

    companion object {
        private const val BASE = "https://speed.cloudflare.com"
        private const val USER_AGENT = "Mozilla/5.0 (Linux; Android) InternetTezligi/2.0"
        private const val THREADS_START = 4
        private const val THREADS_BOOST = 4
        private const val BOOST_DOWN_MBPS = 90.0
        private const val BOOST_UP_MBPS = 40.0
        private const val PING_COUNT = 12
        private const val PING_TIMEOUT = 3000
        private const val IO_TIMEOUT = 8000
        private const val DOWNLOAD_SECONDS = 10
        private const val UPLOAD_SECONDS = 9
        private const val WARMUP_SECONDS = 2.0
        private const val DOWN_CHUNK = 25_000_000
        private const val UP_CHUNK_MIN = 128 * 1024
        private const val UP_CHUNK_MAX = 4 * 1024 * 1024
        private const val SAMPLE_MS = 100L
        private const val WINDOW_NS = 1_000_000_000L
        private const val WORKER_PRIORITY = 5 // UI oqimidan past - interfeys qotmaydi

        /** Provayder, server joyi va IP (Cloudflare /meta). Xato bo'lsa null. */
        fun fetchServerInfo(): ServerInfo? {
            return try {
                val c = URL("$BASE/meta").openConnection() as HttpURLConnection
                c.connectTimeout = 5000
                c.readTimeout = 5000
                c.useCaches = false
                c.setRequestProperty("User-Agent", USER_AGENT)
                val text = try {
                    c.inputStream.bufferedReader().use { it.readText() }
                } finally {
                    c.disconnect()
                }
                val j = JSONObject(text)
                val isp = j.optString("asOrganization", "")
                val ip = j.optString("clientIp", "")
                val coloObj = j.optJSONObject("colo")
                val server = if (coloObj != null) {
                    val city = coloObj.optString("city", "")
                    if (city.isNotEmpty()) city else coloObj.optString("iata", "")
                } else {
                    j.optString("colo", "")
                }
                if (isp.isEmpty() && server.isEmpty() && ip.isEmpty()) null
                else ServerInfo(isp, server, ip)
            } catch (e: Exception) {
                null
            }
        }
    }
}
