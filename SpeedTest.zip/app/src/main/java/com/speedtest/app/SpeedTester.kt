package com.speedtest.app

import android.os.Process
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Collections
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs
import kotlin.math.min

class SpeedTester(private val listener: Listener) {

    enum class Phase { PING, DOWNLOAD, UPLOAD }

    /** Barcha callbacklar fon oqimidan chaqiriladi - UI ga runOnUiThread bilan o'tkazing. */
    interface Listener {
        fun onPhase(phase: Phase)
        fun onPing(pingMs: Int, jitterMs: Int)
        fun onSpeed(phase: Phase, mbps: Double)
        fun onResult(phase: Phase, mbps: Double)
        fun onDone()
        fun onError(message: String)
    }

    private val cancelled = AtomicBoolean(false)
    private val connections = Collections.synchronizedSet(HashSet<HttpURLConnection>())

    fun start() {
        cancelled.set(false)
        Thread {
            Process.setThreadPriority(WORKER_PRIORITY)
            execute()
        }.start()
    }

    fun cancel() {
        cancelled.set(true)
        closeAll()
    }

    private fun emit(block: () -> Unit) {
        if (!cancelled.get()) block()
    }

    private fun execute() {
        try {
            emit { listener.onPhase(Phase.PING) }
            val (ping, jitter) = measurePing()
            if (cancelled.get()) return
            emit { listener.onPing(ping, jitter) }

            emit { listener.onPhase(Phase.DOWNLOAD) }
            val down = measureThroughput(Phase.DOWNLOAD, DOWNLOAD_SECONDS)
            if (cancelled.get()) return
            emit { listener.onResult(Phase.DOWNLOAD, down) }

            emit { listener.onPhase(Phase.UPLOAD) }
            val up = measureThroughput(Phase.UPLOAD, UPLOAD_SECONDS)
            if (cancelled.get()) return
            emit { listener.onResult(Phase.UPLOAD, up) }

            emit { listener.onDone() }
        } catch (e: Exception) {
            emit { listener.onError(e.message ?: "Noma'lum xato") }
        }
    }

    private fun open(url: String, track: Boolean): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.useCaches = false
        c.setRequestProperty("Accept-Encoding", "identity")
        c.setRequestProperty("Cache-Control", "no-cache")
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) InternetTezligi/1.0")
        if (track) connections.add(c)
        return c
    }

    private fun closeAll() {
        val copy = synchronized(connections) { connections.toList() }
        connections.clear()
        for (c in copy) {
            try {
                c.disconnect()
            } catch (ignored: Exception) {
            }
        }
    }

    private fun measurePing(): Pair<Int, Int> {
        val samples = ArrayList<Double>()
        val skip = ByteArray(1024)
        for (i in 0 until PING_COUNT) {
            if (cancelled.get()) break
            val t0 = System.nanoTime()
            val c = open("$BASE/__down?bytes=0", false)
            try {
                c.inputStream.use { while (it.read(skip) >= 0) { /* drain */ } }
            } catch (e: IOException) {
                throw IOException("Serverga ulanib bo'lmadi. Internetni tekshiring.")
            }
            val ms = (System.nanoTime() - t0) / 1_000_000.0
            if (i > 0) samples.add(ms) // birinchisi (TLS) hisobga olinmaydi
            Thread.sleep(80)
        }
        if (samples.isEmpty()) return Pair(0, 0)
        val avg = samples.average()
        var jitter = 0.0
        for (i in 1 until samples.size) jitter += abs(samples[i] - samples[i - 1])
        if (samples.size > 1) jitter /= (samples.size - 1)
        return Pair(avg.toInt(), jitter.toInt())
    }

    private fun measureThroughput(phase: Phase, durationSec: Int): Double {
        val total = AtomicLong(0)
        val stop = AtomicBoolean(false)
        val workers = List(THREADS) {
            Thread { worker(phase, total, stop) }.also { it.start() }
        }

        val t0 = System.nanoTime()
        // Oxirgi ~1 soniyalik oyna bo'yicha tezlik - ko'rsatkich silliq va barqaror bo'ladi
        val times = ArrayDeque<Long>()
        val bytesQ = ArrayDeque<Long>()
        times.addLast(t0)
        bytesQ.addLast(0L)

        var warmB = -1L
        var warmT = 0L
        var result = 0.0

        try {
            while (true) {
                Thread.sleep(SAMPLE_MS)
                if (cancelled.get()) return 0.0
                val now = System.nanoTime()
                val b = total.get()
                val elapsed = (now - t0) / 1e9

                times.addLast(now)
                bytesQ.addLast(b)
                while (times.size > 2 && now - times.first() > WINDOW_NS) {
                    times.removeFirst()
                    bytesQ.removeFirst()
                }
                val dt = (now - times.first()) / 1e9
                val speed = if (dt > 0) (b - bytesQ.first()) * 8.0 / dt / 1e6 else 0.0

                if (warmB < 0 && elapsed >= WARMUP_SECONDS) {
                    warmB = b
                    warmT = now
                }
                emit { listener.onSpeed(phase, speed) }

                if (b == 0L && elapsed > 6) {
                    throw IOException("Serverga ulanib bo'lmadi. Internetni tekshiring.")
                }
                if (elapsed >= durationSec) break
            }
            val bytes = total.get() - warmB
            val secs = (System.nanoTime() - warmT) / 1e9
            result = bytes * 8.0 / secs / 1e6
        } finally {
            stop.set(true)
            closeAll()
            workers.forEach { it.join(1500) }
        }
        return result
    }

    private fun worker(phase: Phase, total: AtomicLong, stop: AtomicBoolean) {
        Process.setThreadPriority(WORKER_PRIORITY)
        val buf = ByteArray(64 * 1024)
        while (!stop.get() && !cancelled.get()) {
            try {
                if (phase == Phase.DOWNLOAD) {
                    val c = open("$BASE/__down?bytes=$DOWN_CHUNK", true)
                    c.inputStream.use { ins ->
                        while (!stop.get()) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            total.addAndGet(n.toLong())
                        }
                    }
                } else {
                    val c = open("$BASE/__up", true)
                    c.requestMethod = "POST"
                    c.doOutput = true
                    c.setRequestProperty("Content-Type", "application/octet-stream")
                    c.setFixedLengthStreamingMode(UP_CHUNK)
                    c.outputStream.use { os ->
                        var sent = 0
                        while (sent < UP_CHUNK && !stop.get()) {
                            val n = min(buf.size, UP_CHUNK - sent)
                            os.write(buf, 0, n)
                            sent += n
                            total.addAndGet(n.toLong())
                        }
                    }
                    c.responseCode
                }
            } catch (e: Exception) {
                if (stop.get() || cancelled.get()) return
                try {
                    Thread.sleep(300)
                } catch (ignored: InterruptedException) {
                    return
                }
            }
        }
    }

    companion object {
        private const val BASE = "https://speed.cloudflare.com"
        private const val THREADS = 4
        private const val PING_COUNT = 10
        private const val DOWNLOAD_SECONDS = 10
        private const val UPLOAD_SECONDS = 8
        private const val WARMUP_SECONDS = 2.0
        private const val DOWN_CHUNK = 25_000_000
        private const val UP_CHUNK = 4_000_000
        private const val SAMPLE_MS = 100L
        private const val WINDOW_NS = 1_000_000_000L
        private const val WORKER_PRIORITY = 5 // UI oqimidan past - interfeys qotmaydi
    }
}
