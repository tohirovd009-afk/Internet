package com.speedtest.app

import android.app.Activity
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity(), SpeedTester.Listener {

    private lateinit var gauge: GaugeView
    private lateinit var tvNet: TextView
    private lateinit var tvPhase: TextView
    private lateinit var tvPing: TextView
    private lateinit var tvJitter: TextView
    private lateinit var tvDown: TextView
    private lateinit var tvUp: TextView
    private lateinit var btn: Button

    private var tester: SpeedTester? = null
    private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        gauge = findViewById(R.id.gauge)
        tvNet = findViewById(R.id.tvNet)
        tvPhase = findViewById(R.id.tvPhase)
        tvPing = findViewById(R.id.tvPing)
        tvJitter = findViewById(R.id.tvJitter)
        tvDown = findViewById(R.id.tvDown)
        tvUp = findViewById(R.id.tvUp)
        btn = findViewById(R.id.btn)

        btn.setOnClickListener { if (running) stopTest() else startTest() }
    }

    override fun onResume() {
        super.onResume()
        tvNet.text = networkName()
    }

    override fun onDestroy() {
        tester?.cancel()
        super.onDestroy()
    }

    private fun networkName(): String {
        return try {
            val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            when {
                caps == null -> "Internet yo'q"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobil internet"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                else -> "Ulangan"
            }
        } catch (e: Exception) {
            "..."
        }
    }

    private fun startTest() {
        running = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        tvNet.text = networkName()
        tvPing.text = "--"
        tvJitter.text = "Jitter: --"
        tvDown.text = "--"
        tvUp.text = "--"
        gauge.reset()
        btn.text = "TO'XTATISH"
        tester = SpeedTester(this).also { it.start() }
    }

    private fun stopTest() {
        tester?.cancel()
        tester = null
        finishUi("To'xtatildi")
    }

    private fun finishUi(status: String) {
        running = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        btn.text = "QAYTA BOSHLASH"
        tvPhase.text = status
    }

    override fun onPhase(phase: SpeedTester.Phase) {
        runOnUiThread {
            tvPhase.text = when (phase) {
                SpeedTester.Phase.PING -> "Ping o'lchanmoqda..."
                SpeedTester.Phase.DOWNLOAD -> "Download o'lchanmoqda..."
                SpeedTester.Phase.UPLOAD -> "Upload o'lchanmoqda..."
            }
            gauge.reset()
        }
    }

    override fun onPing(pingMs: Int, jitterMs: Int) {
        runOnUiThread {
            tvPing.text = pingMs.toString()
            tvJitter.text = "Jitter: $jitterMs ms"
        }
    }

    override fun onSpeed(phase: SpeedTester.Phase, mbps: Double) {
        runOnUiThread {
            gauge.setSpeed(mbps)
            when (phase) {
                SpeedTester.Phase.DOWNLOAD -> tvDown.text = formatSpeed(mbps)
                SpeedTester.Phase.UPLOAD -> tvUp.text = formatSpeed(mbps)
                else -> {}
            }
        }
    }

    override fun onResult(phase: SpeedTester.Phase, mbps: Double) {
        runOnUiThread {
            gauge.setSpeed(mbps)
            when (phase) {
                SpeedTester.Phase.DOWNLOAD -> tvDown.text = formatSpeed(mbps)
                SpeedTester.Phase.UPLOAD -> tvUp.text = formatSpeed(mbps)
                else -> {}
            }
        }
    }

    override fun onDone() {
        runOnUiThread { finishUi("Tayyor") }
    }

    override fun onError(message: String) {
        runOnUiThread {
            finishUi("Xato")
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        }
    }
}
