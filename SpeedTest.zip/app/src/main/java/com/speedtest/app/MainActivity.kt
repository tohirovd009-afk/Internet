package com.speedtest.app

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Activity
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min

class MainActivity : Activity(), SpeedTester.Listener {

    private lateinit var prefs: SharedPreferences

    private lateinit var gauge: GaugeView
    private lateinit var idleGroup: View
    private lateinit var testGroup: View
    private lateinit var pageSpeed: View
    private lateinit var pageHistory: View
    private lateinit var pageNet: View
    private lateinit var btnClose: View
    private lateinit var goButton: View
    private lateinit var progressTrack: View
    private lateinit var progressFill: View
    private lateinit var btnRetry: View

    private lateinit var tvIsp: TextView
    private lateinit var tvDevice: TextView
    private lateinit var tvServer: TextView
    private lateinit var tvServerCity: TextView
    private lateinit var tvIspT: TextView
    private lateinit var tvDevT: TextView
    private lateinit var tvServerT: TextView
    private lateinit var tvCityT: TextView

    private lateinit var tgUnits: LinearLayout
    private lateinit var tgScale: LinearLayout
    private lateinit var tgConn: LinearLayout

    private lateinit var boxDown: View
    private lateinit var boxUp: View
    private lateinit var tvDown: TextView
    private lateinit var tvUp: TextView
    private lateinit var tvDownUnit: TextView
    private lateinit var tvUpUnit: TextView
    private lateinit var tvPing: TextView
    private lateinit var tvJitter: TextView
    private lateinit var dotsWeb: TextView
    private lateinit var dotsGame: TextView
    private lateinit var dotsVideo: TextView
    private lateinit var dotsCall: TextView

    private lateinit var historyList: LinearLayout
    private lateinit var netList: LinearLayout
    private lateinit var icSpeed: ImageView
    private lateinit var icHist: ImageView
    private lateinit var icNet: ImageView
    private lateinit var lblSpeed: TextView
    private lateinit var lblHist: TextView
    private lateinit var lblNet: TextView

    // sozlamalar
    private val unitNames = arrayOf("Mbps", "MB/s", "kB/s")
    private val scaleValues = intArrayOf(100, 500, 1000)
    private var unitIndex = 0
    private var scaleIndex = 2
    private var multi = true

    // holat
    private var tester: SpeedTester? = null
    private var running = false
    private var testMode = false
    private var currentTab = 0
    private var netInfo: NetInfo? = null
    private var pulse: ObjectAnimator? = null

    private var lastDown = -1.0
    private var lastUp = -1.0
    private var lastPing = -1
    private var lastJitter = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("settings", MODE_PRIVATE)
        unitIndex = prefs.getInt("unit", 0).coerceIn(0, 2)
        scaleIndex = prefs.getInt("scale", 2).coerceIn(0, 2)
        multi = prefs.getBoolean("multi", true)

        bindViews()

        tvDevice.text = Build.MODEL
        tvDevT.text = Build.MODEL

        buildToggle(tgUnits, unitNames.toList(), unitIndex) {
            unitIndex = it
            prefs.edit().putInt("unit", it).apply()
            applyUnit()
        }
        buildToggle(tgScale, scaleValues.map { it.toString() }, scaleIndex) {
            scaleIndex = it
            prefs.edit().putInt("scale", it).apply()
            gauge.setScale(scaleValues[it])
        }
        buildToggle(tgConn, listOf("Multi", "Single"), if (multi) 0 else 1) {
            multi = it == 0
            prefs.edit().putBoolean("multi", multi).apply()
        }

        gauge.setScale(scaleValues[scaleIndex])
        applyUnit()

        goButton.setOnClickListener { startTest() }
        btnRetry.setOnClickListener { startTest() }
        btnClose.setOnClickListener { closeTest() }
        findViewById<View>(R.id.navSpeed).setOnClickListener { selectTab(0) }
        findViewById<View>(R.id.navHist).setOnClickListener { selectTab(1) }
        findViewById<View>(R.id.navNet).setOnClickListener { selectTab(2) }

        selectTab(0)
        applyNetInfo()
        loadNetInfo()
    }

    private fun bindViews() {
        gauge = findViewById(R.id.gauge)
        idleGroup = findViewById(R.id.idleGroup)
        testGroup = findViewById(R.id.testGroup)
        pageSpeed = findViewById(R.id.pageSpeed)
        pageHistory = findViewById(R.id.pageHistory)
        pageNet = findViewById(R.id.pageNet)
        btnClose = findViewById(R.id.btnClose)
        goButton = findViewById(R.id.goButton)
        progressTrack = findViewById(R.id.progressTrack)
        progressFill = findViewById(R.id.progressFill)
        btnRetry = findViewById(R.id.btnRetry)

        tvIsp = findViewById(R.id.tvIsp)
        tvDevice = findViewById(R.id.tvDevice)
        tvServer = findViewById(R.id.tvServer)
        tvServerCity = findViewById(R.id.tvServerCity)
        tvIspT = findViewById(R.id.tvIspT)
        tvDevT = findViewById(R.id.tvDevT)
        tvServerT = findViewById(R.id.tvServerT)
        tvCityT = findViewById(R.id.tvCityT)

        tgUnits = findViewById(R.id.tgUnits)
        tgScale = findViewById(R.id.tgScale)
        tgConn = findViewById(R.id.tgConn)

        boxDown = findViewById(R.id.boxDown)
        boxUp = findViewById(R.id.boxUp)
        tvDown = findViewById(R.id.tvDown)
        tvUp = findViewById(R.id.tvUp)
        tvDownUnit = findViewById(R.id.tvDownUnit)
        tvUpUnit = findViewById(R.id.tvUpUnit)
        tvPing = findViewById(R.id.tvPing)
        tvJitter = findViewById(R.id.tvJitter)
        dotsWeb = findViewById(R.id.dotsWeb)
        dotsGame = findViewById(R.id.dotsGame)
        dotsVideo = findViewById(R.id.dotsVideo)
        dotsCall = findViewById(R.id.dotsCall)

        historyList = findViewById(R.id.historyList)
        netList = findViewById(R.id.netList)
        icSpeed = findViewById(R.id.icSpeed)
        icHist = findViewById(R.id.icHist)
        icNet = findViewById(R.id.icNet)
        lblSpeed = findViewById(R.id.lblSpeed)
        lblHist = findViewById(R.id.lblHist)
        lblNet = findViewById(R.id.lblNet)
    }

    override fun onResume() {
        super.onResume()
        if (netInfo == null) loadNetInfo()
        applyNetInfo()
        updatePulse()
    }

    override fun onPause() {
        stopPulse()
        super.onPause()
    }

    override fun onDestroy() {
        tester?.cancel()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (testMode && currentTab == 0) closeTest() else super.onBackPressed()
    }

    // ---------- Yordamchilar ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun conv(mbps: Double): Double = when (unitIndex) {
        1 -> mbps / 8.0
        2 -> mbps * 125.0
        else -> mbps
    }

    private fun networkName(): String {
        return try {
            val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            when {
                caps == null -> "Internet yo'q"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobil internet"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                else -> "Ulangan"
            }
        } catch (e: Exception) {
            "Internet"
        }
    }

    private fun ispName(): String {
        val s = netInfo?.isp ?: ""
        return if (s.isNotBlank()) s.uppercase() else networkName().uppercase()
    }

    private fun buildToggle(
        container: LinearLayout,
        options: List<String>,
        selected: Int,
        onSelect: (Int) -> Unit
    ) {
        container.removeAllViews()
        options.forEachIndexed { i, text ->
            val tv = TextView(this)
            tv.text = text
            tv.textSize = 17f
            tv.typeface = Typeface.DEFAULT_BOLD
            tv.setPadding(dp(11), dp(8), dp(11), dp(8))
            if (i == selected) {
                tv.setTextColor(Color.WHITE)
                tv.setBackgroundResource(R.drawable.bg_underline)
            } else {
                tv.setTextColor(0xFF7C86AA.toInt())
            }
            tv.setOnClickListener {
                onSelect(i)
                buildToggle(container, options, i, onSelect)
            }
            container.addView(tv)
        }
    }

    private fun applyUnit() {
        val u = unitNames[unitIndex]
        tvDownUnit.text = u
        tvUpUnit.text = u
        gauge.setUnit(u)
        if (lastDown >= 0) tvDown.text = formatSpeed(conv(lastDown))
        if (lastUp >= 0) tvUp.text = formatSpeed(conv(lastUp))
    }

    // ---------- Tarmoq ma'lumoti ----------

    private fun loadNetInfo() {
        Thread {
            val info = NetInfoLoader.load()
            runOnUiThread {
                if (info != null) {
                    netInfo = info
                    applyNetInfo()
                    if (currentTab == 2) renderNet()
                }
            }
        }.start()
    }

    private fun applyNetInfo() {
        val isp = ispName()
        tvIsp.text = isp
        tvIspT.text = isp
        val colo = netInfo?.colo ?: ""
        val city = if (colo.isNotBlank()) colo else "—"
        tvServerCity.text = city
        tvCityT.text = city
    }

    private fun renderNet() {
        netList.removeAllViews()
        val n = netInfo
        fun v(s: String?): String = if (s.isNullOrBlank()) "—" else s
        val place = listOfNotNull(
            n?.city?.takeIf { it.isNotBlank() },
            n?.country?.takeIf { it.isNotBlank() }
        ).joinToString(", ")
        addRow(netList, "Tarmoq turi", networkName())
        addRow(netList, "IP manzil", v(n?.ip))
        addRow(netList, "Provayder", v(n?.isp))
        addRow(netList, "ASN", v(n?.asn))
        addRow(netList, "Joylashuv", v(place))
        addRow(netList, "Test serveri", "Cloudflare " + v(n?.colo))
        addRow(netList, "Qurilma", Build.MODEL)
    }

    private fun addRow(parent: LinearLayout, key: String, value: String) {
        val row = LayoutInflater.from(this).inflate(R.layout.item_info, parent, false)
        row.findViewById<TextView>(R.id.iKey).text = key
        row.findViewById<TextView>(R.id.iValue).text = value
        parent.addView(row)
    }

    private fun renderHistory() {
        historyList.removeAllViews()
        val items = HistoryStore.all(this)
        if (items.isEmpty()) {
            val tv = TextView(this)
            tv.text = "Hozircha natijalar yo'q"
            tv.setTextColor(0xFF8A94B8.toInt())
            tv.textSize = 15f
            historyList.addView(tv)
            return
        }
        val fmt = SimpleDateFormat("dd.MM.yyyy  HH:mm", Locale.US)
        for (e in items) {
            val row = LayoutInflater.from(this).inflate(R.layout.item_history, historyList, false)
            row.findViewById<TextView>(R.id.hDate).text = fmt.format(Date(e.time))
            row.findViewById<TextView>(R.id.hIsp).text = e.isp
            row.findViewById<TextView>(R.id.hSpeed).text =
                "↓ " + formatSpeed(e.down) + "   ↑ " + formatSpeed(e.up) + " Mbps"
            row.findViewById<TextView>(R.id.hPing).text = "Ping " + e.ping + " ms"
            historyList.addView(row)
        }
    }

    // ---------- Tablar va ko'rinish ----------

    private fun selectTab(i: Int) {
        currentTab = i
        pageSpeed.visibility = if (i == 0) View.VISIBLE else View.GONE
        pageHistory.visibility = if (i == 1) View.VISIBLE else View.GONE
        pageNet.visibility = if (i == 2) View.VISIBLE else View.GONE
        val on = 0xFFF5C451.toInt()
        val off = 0xFF6B7394.toInt()
        icSpeed.setColorFilter(if (i == 0) on else off)
        icHist.setColorFilter(if (i == 1) on else off)
        icNet.setColorFilter(if (i == 2) on else off)
        lblSpeed.setTextColor(if (i == 0) on else off)
        lblHist.setTextColor(if (i == 1) on else off)
        lblNet.setTextColor(if (i == 2) on else off)
        if (i == 1) renderHistory()
        if (i == 2) renderNet()
        updateChrome()
        updatePulse()
    }

    private fun updateChrome() {
        val show = currentTab == 0 && testMode
        btnClose.visibility = if (show) View.VISIBLE else View.INVISIBLE
        progressTrack.visibility = if (show) View.VISIBLE else View.INVISIBLE
    }

    private fun showTestUi(on: Boolean) {
        testMode = on
        idleGroup.visibility = if (on) View.GONE else View.VISIBLE
        testGroup.visibility = if (on) View.VISIBLE else View.GONE
        updateChrome()
        updatePulse()
    }

    private fun updatePulse() {
        if (!testMode && currentTab == 0) startPulse() else stopPulse()
    }

    private fun startPulse() {
        if (pulse == null) {
            pulse = ObjectAnimator.ofPropertyValuesHolder(
                goButton,
                PropertyValuesHolder.ofFloat("scaleX", 1f, 1.05f),
                PropertyValuesHolder.ofFloat("scaleY", 1f, 1.05f)
            ).apply {
                duration = 1300
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.REVERSE
            }
        }
        if (pulse?.isStarted != true) pulse?.start()
    }

    private fun stopPulse() {
        pulse?.cancel()
        goButton.scaleX = 1f
        goButton.scaleY = 1f
    }

    private fun setActiveBox(phase: SpeedTester.Phase?) {
        boxDown.setBackgroundResource(
            if (phase == SpeedTester.Phase.DOWNLOAD) R.drawable.bg_box_down else R.drawable.bg_box
        )
        boxUp.setBackgroundResource(
            if (phase == SpeedTester.Phase.UPLOAD) R.drawable.bg_box_up else R.drawable.bg_box
        )
    }

    private fun setProgress(f: Float) {
        progressFill.pivotX = 0f
        progressFill.scaleX = f.coerceIn(0f, 1f)
    }

    // ---------- Test boshqaruvi ----------

    private fun startTest() {
        tester?.cancel()
        running = true
        lastDown = -1.0
        lastUp = -1.0
        lastPing = -1
        lastJitter = 0

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        showTestUi(true)
        btnRetry.visibility = View.GONE
        tvDown.text = "—"
        tvUp.text = "—"
        tvPing.text = "—"
        tvJitter.text = "—"
        val empty = "○○○○○"
        dotsWeb.text = empty
        dotsGame.text = empty
        dotsVideo.text = empty
        dotsCall.text = empty
        setActiveBox(null)
        setProgress(0f)
        gauge.reset()
        gauge.setPhase(0)
        applyNetInfo()

        tester = SpeedTester(this, if (multi) 4 else 1).also { it.start() }
    }

    private fun closeTest() {
        tester?.cancel()
        tester = null
        running = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        showTestUi(false)
    }

    private fun dots(n: Int): String {
        val k = n.coerceIn(0, 5)
        return "●".repeat(k) + "○".repeat(5 - k)
    }

    private fun level(v: Double, t: DoubleArray): Int {
        var n = 1
        for (x in t) if (v >= x) n++
        return n
    }

    private fun updateQuality() {
        val d = lastDown
        val u = lastUp
        dotsWeb.text = dots(level(d, doubleArrayOf(1.0, 3.0, 10.0, 25.0)))
        dotsVideo.text = dots(level(d, doubleArrayOf(2.0, 5.0, 12.0, 25.0)))
        dotsCall.text = dots(level(min(d, u), doubleArrayOf(1.0, 3.0, 6.0, 12.0)))
        var g = when {
            lastPing <= 20 -> 5
            lastPing <= 40 -> 4
            lastPing <= 70 -> 3
            lastPing <= 120 -> 2
            else -> 1
        }
        if (lastJitter > 30) g -= 1
        dotsGame.text = dots(g.coerceAtLeast(1))
    }

    // ---------- SpeedTester.Listener (fon oqimidan) ----------

    override fun onPhase(phase: SpeedTester.Phase) {
        runOnUiThread {
            gauge.reset()
            when (phase) {
                SpeedTester.Phase.PING -> {
                    gauge.setPhase(0)
                    setActiveBox(null)
                }
                SpeedTester.Phase.DOWNLOAD -> {
                    gauge.setPhase(1)
                    setActiveBox(phase)
                }
                SpeedTester.Phase.UPLOAD -> {
                    gauge.setPhase(2)
                    setActiveBox(phase)
                }
            }
        }
    }

    override fun onPing(pingMs: Int, jitterMs: Int) {
        runOnUiThread {
            lastPing = pingMs
            lastJitter = jitterMs
            tvPing.text = pingMs.toString()
            tvJitter.text = jitterMs.toString()
        }
    }

    override fun onSpeed(phase: SpeedTester.Phase, mbps: Double) {
        runOnUiThread {
            val c = conv(mbps)
            gauge.setSpeed(mbps, formatReadout(c))
            when (phase) {
                SpeedTester.Phase.DOWNLOAD -> tvDown.text = formatSpeed(c)
                SpeedTester.Phase.UPLOAD -> tvUp.text = formatSpeed(c)
                else -> {}
            }
        }
    }

    override fun onProgress(fraction: Float) {
        runOnUiThread { setProgress(fraction) }
    }

    override fun onResult(phase: SpeedTester.Phase, mbps: Double) {
        runOnUiThread {
            val c = conv(mbps)
            gauge.setSpeed(mbps, formatReadout(c))
            when (phase) {
                SpeedTester.Phase.DOWNLOAD -> {
                    lastDown = mbps
                    tvDown.text = formatSpeed(c)
                }
                SpeedTester.Phase.UPLOAD -> {
                    lastUp = mbps
                    tvUp.text = formatSpeed(c)
                }
                else -> {}
            }
        }
    }

    override fun onDone() {
        runOnUiThread {
            running = false
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            setActiveBox(null)
            setProgress(1f)
            updateQuality()
            btnRetry.visibility = View.VISIBLE
            HistoryStore.add(
                this,
                HistoryEntry(
                    System.currentTimeMillis(), ispName(),
                    lastDown.coerceAtLeast(0.0), lastUp.coerceAtLeast(0.0),
                    lastPing.coerceAtLeast(0), lastJitter
                )
            )
        }
    }

    override fun onError(message: String) {
        runOnUiThread {
            running = false
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            setActiveBox(null)
            btnRetry.visibility = View.VISIBLE
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        }
    }
}
