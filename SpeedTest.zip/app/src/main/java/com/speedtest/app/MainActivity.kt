package com.speedtest.app

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : BaseActivity(), SpeedTester.Listener {

    private lateinit var gauge: GaugeView
    private lateinit var tvNet: TextView
    private lateinit var tvLang: TextView
    private lateinit var tvInfo: TextView
    private lateinit var tvPhase: TextView
    private lateinit var tvPing: TextView
    private lateinit var tvJitter: TextView
    private lateinit var tvLoss: TextView
    private lateinit var tvLoaded: TextView
    private lateinit var tvData: TextView
    private lateinit var tvDown: TextView
    private lateinit var tvUp: TextView
    private lateinit var cardVerdict: View
    private lateinit var tvVerdictTitle: TextView
    private lateinit var tvVerdictBody: TextView
    private lateinit var btn: Button
    private lateinit var btnShare: Button
    private lateinit var btnHistory: Button

    private var tester: SpeedTester? = null
    private var running = false
    private var cellularWarned = false
    private var netCallback: ConnectivityManager.NetworkCallback? = null

    private var downMbps = 0.0
    private var upMbps = 0.0
    private var pingMs = 0
    private var jitterMs = 0
    private var lossPct = 0
    private var loadedMs = 0
    private var finished = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        gauge = findViewById(R.id.gauge)
        tvNet = findViewById(R.id.tvNet)
        tvLang = findViewById(R.id.tvLang)
        tvInfo = findViewById(R.id.tvInfo)
        tvPhase = findViewById(R.id.tvPhase)
        tvPing = findViewById(R.id.tvPing)
        tvJitter = findViewById(R.id.tvJitter)
        tvLoss = findViewById(R.id.tvLoss)
        tvLoaded = findViewById(R.id.tvLoaded)
        tvData = findViewById(R.id.tvData)
        tvDown = findViewById(R.id.tvDown)
        tvUp = findViewById(R.id.tvUp)
        cardVerdict = findViewById(R.id.cardVerdict)
        tvVerdictTitle = findViewById(R.id.tvVerdictTitle)
        tvVerdictBody = findViewById(R.id.tvVerdictBody)
        btn = findViewById(R.id.btn)
        btnShare = findViewById(R.id.btnShare)
        btnHistory = findViewById(R.id.btnHistory)

        tvLang.text = LocaleHelper.current(this).uppercase(Locale.ROOT)
        tvLang.setOnClickListener {
            tester?.cancel()
            running = false
            LocaleHelper.next(this)
            recreate()
        }

        btn.setOnClickListener { if (running) stopTest() else tryStart() }
        btnShare.setOnClickListener { shareResult() }
        btnHistory.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) }
        btnShare.isEnabled = false

        gauge.contentDescription = getString(R.string.gauge_desc, formatSpeed(0.0))
        showServerInfo(cachedInfo)
        if (cachedInfo == null) loadServerInfo()
    }

    override fun onStart() {
        super.onStart()
        tvNet.text = networkName()
        registerNetworkCallback()
    }

    override fun onStop() {
        unregisterNetworkCallback()
        if (running) {
            stopTest()
            Toast.makeText(this, R.string.stopped_background, Toast.LENGTH_SHORT).show()
        }
        super.onStop()
    }

    override fun onDestroy() {
        tester?.cancel()
        super.onDestroy()
    }

    // ---------- Tarmoq ----------

    private fun connectivity(): ConnectivityManager? =
        getSystemService(ConnectivityManager::class.java)

    private fun activeCaps(): NetworkCapabilities? = try {
        val cm = connectivity()
        if (cm == null) null else cm.getNetworkCapabilities(cm.activeNetwork)
    } catch (e: Exception) {
        null
    }

    private fun hasInternet(): Boolean =
        activeCaps()?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true

    private fun isCellular(): Boolean =
        activeCaps()?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true

    private fun networkName(): String {
        val caps = activeCaps()
        return when {
            caps == null -> getString(R.string.net_none)
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> getString(R.string.net_wifi)
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> getString(R.string.net_mobile)
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> getString(R.string.net_ethernet)
            else -> getString(R.string.net_other)
        }
    }

    private fun registerNetworkCallback() {
        if (netCallback != null) return
        try {
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) = refreshNet()
                override fun onLost(network: Network) = refreshNet()
                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) = refreshNet()
            }
            connectivity()?.registerDefaultNetworkCallback(cb)
            netCallback = cb
        } catch (e: Exception) {
            netCallback = null
        }
    }

    private fun unregisterNetworkCallback() {
        val cb = netCallback ?: return
        netCallback = null
        try {
            connectivity()?.unregisterNetworkCallback(cb)
        } catch (ignored: Exception) {
        }
    }

    private fun refreshNet() {
        runOnUiThread { if (!isFinishing) tvNet.text = networkName() }
    }

    private fun loadServerInfo() {
        Thread {
            val info = SpeedTester.fetchServerInfo()
            runOnUiThread {
                if (info != null) cachedInfo = info
                if (!isFinishing) showServerInfo(info)
            }
        }.start()
    }

    private fun showServerInfo(info: SpeedTester.ServerInfo?) {
        tvInfo.text = infoLine(info)
    }

    private fun infoLine(info: SpeedTester.ServerInfo?): String {
        if (info == null) return getString(R.string.server_default)
        val parts = ArrayList<String>()
        if (info.isp.isNotEmpty()) parts.add(info.isp)
        parts.add(
            if (info.server.isNotEmpty()) getString(R.string.server_fmt, info.server)
            else getString(R.string.server_default)
        )
        return parts.joinToString("  \u2022  ")
    }

    // ---------- Boshqaruv ----------

    private fun tryStart() {
        if (!hasInternet()) {
            Toast.makeText(this, R.string.err_no_internet, Toast.LENGTH_LONG).show()
            return
        }
        if (isCellular() && !cellularWarned) {
            AlertDialog.Builder(this)
                .setTitle(R.string.mobile_warn_title)
                .setMessage(R.string.mobile_warn_msg)
                .setPositiveButton(R.string.btn_continue) { _, _ ->
                    cellularWarned = true
                    startTest()
                }
                .setNegativeButton(R.string.btn_cancel, null)
                .show()
            return
        }
        startTest()
    }

    private fun startTest() {
        running = true
        finished = false
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        tvNet.text = networkName()
        downMbps = 0.0; upMbps = 0.0; pingMs = 0; jitterMs = 0; lossPct = 0; loadedMs = 0
        tvPing.text = "--"
        tvJitter.text = "--"
        tvLoss.text = "--"
        tvLoaded.text = "--"
        tvData.text = "--"
        tvDown.text = "--"
        tvUp.text = "--"
        cardVerdict.visibility = View.GONE
        btnShare.isEnabled = false
        btnHistory.isEnabled = false
        gauge.reset()
        gauge.setLabel("")
        btn.setText(R.string.btn_stop)
        btn.setBackgroundResource(R.drawable.bg_button_stop)
        btn.setTextColor(Color.WHITE)
        tester = SpeedTester(this).also { it.start() }
    }

    private fun stopTest() {
        tester?.cancel()
        tester = null
        gauge.reset()
        gauge.setLabel("")
        finishUi(getString(R.string.status_stopped))
    }

    private fun finishUi(status: String) {
        running = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        btn.setText(R.string.btn_restart)
        btn.setBackgroundResource(R.drawable.bg_button)
        btn.setTextColor(0xFF04121A.toInt())
        btnHistory.isEnabled = true
        tvPhase.text = status
    }

    // ---------- Natijalar ----------

    private fun buildVerdict() {
        val title = when {
            downMbps >= 100 -> R.string.verdict_excellent
            downMbps >= 25 -> R.string.verdict_good
            downMbps >= 5 -> R.string.verdict_average
            else -> R.string.verdict_slow
        }
        val calls = pingMs in 1..149 && jitterMs < 40 && lossPct < 5 && downMbps >= 1 && upMbps >= 1
        val hd = downMbps >= 8
        val uhd = downMbps >= 25
        val game = pingMs < 60 && jitterMs < 30 && lossPct < 2 && downMbps >= 3
        val conf = downMbps >= 5 && upMbps >= 3 && pingMs < 150 && lossPct < 5

        val body = SpannableStringBuilder()
        fun line(ok: Boolean, res: Int) {
            val start = body.length
            body.append(if (ok) "\u2714  " else "\u2716  ")
            body.setSpan(
                ForegroundColorSpan(if (ok) 0xFF00E5A8.toInt() else 0xFFF43F5E.toInt()),
                start, body.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            body.append(getString(res)).append('\n')
        }
        line(calls, R.string.act_calls)
        line(hd, R.string.act_hd)
        line(uhd, R.string.act_4k)
        line(conf, R.string.act_conf)
        line(game, R.string.act_game)
        if (body.isNotEmpty()) body.delete(body.length - 1, body.length)

        tvVerdictTitle.setText(title)
        tvVerdictBody.text = body
        cardVerdict.visibility = View.VISIBLE
    }

    private fun saveHistory() {
        val info = cachedInfo
        HistoryStore.add(
            this,
            HistoryEntry(
                System.currentTimeMillis(), networkName(),
                downMbps, upMbps, pingMs, jitterMs, lossPct, loadedMs,
                info?.isp ?: "", info?.server ?: ""
            )
        )
    }

    private fun shareResult() {
        if (!finished) return
        val text = getString(
            R.string.share_text,
            formatSpeed(downMbps), formatSpeed(upMbps), pingMs, jitterMs
        )
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(i, getString(R.string.share_title)))
    }

    private fun formatBytes(b: Long): String {
        val mb = b / 1048576.0
        return if (mb >= 1024) String.format(Locale.US, "%.2f GB", mb / 1024)
        else String.format(Locale.US, "%.1f MB", mb)
    }

    // ---------- SpeedTester.Listener ----------

    override fun onPhase(phase: SpeedTester.Phase) {
        runOnUiThread {
            gauge.reset()
            when (phase) {
                SpeedTester.Phase.PING -> {
                    tvPhase.setText(R.string.phase_ping)
                    gauge.setLabel(getString(R.string.lbl_ping))
                }
                SpeedTester.Phase.DOWNLOAD -> {
                    tvPhase.setText(R.string.phase_download)
                    gauge.setLabel(getString(R.string.lbl_download))
                }
                SpeedTester.Phase.UPLOAD -> {
                    tvPhase.setText(R.string.phase_upload)
                    gauge.setLabel(getString(R.string.lbl_upload))
                }
            }
        }
    }

    override fun onPing(result: SpeedTester.PingResult) {
        runOnUiThread {
            pingMs = result.ping
            jitterMs = result.jitter
            lossPct = result.lossPercent
            tvPing.text = pingMs.toString()
            tvJitter.text = jitterMs.toString()
            tvLoss.text = lossPct.toString()
        }
    }

    override fun onSpeed(phase: SpeedTester.Phase, mbps: Double) {
        runOnUiThread {
            gauge.setSpeed(mbps)
            when (phase) {
                SpeedTester.Phase.DOWNLOAD -> tvDown.text = formatSpeed(mbps)
                SpeedTester.Phase.UPLOAD -> tvUp.text = formatSpeed(mbps)
                else -> {}
            }
        }
    }

    override fun onResult(phase: SpeedTester.Phase, mbps: Double) {
        runOnUiThread {
            when (phase) {
                SpeedTester.Phase.DOWNLOAD -> {
                    downMbps = mbps
                    tvDown.text = formatSpeed(mbps)
                }
                SpeedTester.Phase.UPLOAD -> {
                    upMbps = mbps
                    tvUp.text = formatSpeed(mbps)
                }
                else -> {}
            }
        }
    }

    override fun onLoadedPing(ms: Int) {
        runOnUiThread {
            loadedMs = ms
            tvLoaded.text = ms.toString()
        }
    }

    override fun onDone(usedBytes: Long) {
        runOnUiThread {
            finished = true
            tvData.text = formatBytes(usedBytes)
            gauge.reset()
            gauge.setLabel(getString(R.string.lbl_ready))
            gauge.contentDescription = getString(
                R.string.result_desc, formatSpeed(downMbps), formatSpeed(upMbps), pingMs
            )
            buildVerdict()
            saveHistory()
            btnShare.isEnabled = true
            finishUi(getString(R.string.status_done))
        }
    }

    override fun onError() {
        runOnUiThread {
            gauge.reset()
            gauge.setLabel(getString(R.string.lbl_error))
            finishUi(getString(R.string.status_error))
            Toast.makeText(this, R.string.err_server, Toast.LENGTH_LONG).show()
        }
    }

    companion object {
        private var cachedInfo: SpeedTester.ServerInfo? = null
    }
}
